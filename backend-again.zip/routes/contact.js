const express = require('express');
const router = express.Router();

// Contact route
router.get('/contact', (req, res) => {
  res.send('Contact Us');
});

module.exports = router;
